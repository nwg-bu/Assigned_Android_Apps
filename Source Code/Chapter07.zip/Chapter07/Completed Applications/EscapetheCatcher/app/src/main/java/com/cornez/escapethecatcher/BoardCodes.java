package com.cornez.escapethecatcher;

public class BoardCodes {
    final static int isOBSTACLE = 1;
    final  static int isEMPTY = 2;
    final static int isHOME = 3;

}
