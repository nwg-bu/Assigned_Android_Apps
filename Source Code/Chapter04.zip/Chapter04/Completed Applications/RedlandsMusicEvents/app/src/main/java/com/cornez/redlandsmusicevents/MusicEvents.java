package com.cornez.redlandsmusicevents;

public class MusicEvents {

    static public  String[] data = {
            "6/24 - Object of Her Affection",
            "6/25 - Electrogynous",
            "6/26 - The Singing Head",
            "6/27 - Saana the Foreigner",
            "7/22 - Still",
            "7/23 - Iceland",
            "7/24 - Blacktop Highway",
            "7/25 - For Now",
            "8/04 - Beyond",
            "8/07 - Destiny Six",
            "8/08 - What and Why",
            "8/09 - France is Gone!"
    };
}

